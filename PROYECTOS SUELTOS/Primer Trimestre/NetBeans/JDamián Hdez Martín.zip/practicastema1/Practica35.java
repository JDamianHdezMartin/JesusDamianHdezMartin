/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicastema1;

/**
 *
 * @author JDamian Hdez Martin
 */
public class Practica35 {
    public static void main(String[] args) {
        
        for(char letra = 'a' ; letra < 'a' + 10; letra++){
            System.out.println(letra);
        }
        
    }
  
}
