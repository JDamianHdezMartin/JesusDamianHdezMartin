/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicastema1;

/**
 *
 * @author JDamian Hdez Martin
 */
public class PracticaSwitch {
    public static void main(String[] args) {
        
        int a = 5;
        
        switch(a){
            case 2: System.out.println("es 2");
                break;
            case 230: System.out.println("es 230");
                break;
            case 16: System.out.println("es 16");
                break;
            default: System.out.println("no es de los casos registrados");
        }
        
    }
}
