/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicastema1;

/**
 *
 * @author JDamian Hdez Martin
 */
public class Practica06 {
    
    public static void main(String[] args) {
        
        String horario = " L\t M\t X\t J\t V \n"
                + "FOL\tSSF\tFOL\tLNT\tLNT \n"
                + "BAE\tPRO\tFOL\tPRO\tBAE \n"
                + "PRO\tPRO\tETS\tBAE\tLND \n"
                + "SSF\tBAE\tPRO\tBAE\tLND \n"
                + "LND\tETS\tSSF\tSSF\tPRO \n"
                + "LND\tETS\tBAE\tSSF\tPRO \n";
        
        System.out.println(horario);
    }
}
