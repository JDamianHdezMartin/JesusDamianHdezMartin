/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicastema1;

/**
 *
 * @author JDamian Hdez Martin
 */
public class Practica11 {
    public static void main(String[] args) {
        
        int x, y;
        x = 3;
        y = 4;
        y *= ++x;
        System.out.println("x=" + x + " y=" + y);
        //En este caso la x=4 y la y=16
    }
}
