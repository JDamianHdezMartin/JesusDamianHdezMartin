/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicastema1;

/**
 *
 * @author JDamian Hdez Martin
 */
public class Practica05 {
    public static void main(String[] args) {
        
        int numero = 0x10;
        
        System.out.println(numero);
        //aparece el número 16
        System.out.println(067);
        //aparece el número 55
    }
}
